/*6. Функции:*/


/*a) Напишите функцию, которая принимает два числа в качестве аргументов и возвращает их сумму.*/
function sum3(a, b) {
    return a + b;
}

let res = sum3(3, 5);
console.log(res);


/*c) Напишите функцию, которая принимает строку в качестве аргумента и возвращает ее в обратном порядке.*/
function reversestroke(str) {
    return str.split('').reverse().join('');
}
console.log(reversestroke("яакперк атохо"));