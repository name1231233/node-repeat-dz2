

const smartphoneModels = [
  "iPhone 13",
  "Samsung S21",
  "Google Pixel 6",
  "OnePlus 9",
  "Xiaomi Mi 11",
  "Huawei P40",
  "Oppo Find X3",
];

const currencySymbols = [
  "$",
  "€",
  "£",
  "¥",
  "₹",
  "₽",
  "₣",
  "₺",
  "₿",
  "₴",
  "₦",
  "₪",
  "₡",
  "₸",
  "₢",
  "₫",
  "₵",
];

// На будущее :)
const currencyInfo = [
  { symbol: "$", hexCode: "0024" }, // Доллар США
  { symbol: "€", hexCode: "20AC" }, // Евро
  { symbol: "£", hexCode: "00A3" }, // Фунт стерлингов
  { symbol: "¥", hexCode: "00A5" }, // Японская иена
  { symbol: "₹", hexCode: "20B9" }, // Индийская рупия
  { symbol: "₽", hexCode: "20BD" }, // Российский рубль
  { symbol: "₣", hexCode: "20A3" }, // Французский франк
  { symbol: "₺", hexCode: "20BA" }, // Турецкая лира
  { symbol: "₿", hexCode: "20BF" }, // Биткоин
  { symbol: "₴", hexCode: "20B4" }, // Украинская гривна
  { symbol: "₦", hexCode: "20A6" }, // Нигерийская найра
  { symbol: "₪", hexCode: "20AA" }, // Израильский шекель
  { symbol: "₡", hexCode: "20A1" }, // Костариканский колон
  { symbol: "₸", hexCode: "20B8" }, // Казахстанский тенге
  { symbol: "₢", hexCode: "20A2" }, // Бразильский крузейро
  { symbol: "₫", hexCode: "20AB" }, // Вьетнамский донг
  { symbol: "₵", hexCode: "20B5" }, // Ганский седи
];

module.exports = {
  smartphoneModels,
  currencySymbols,
  currencyInfo,
};
