const {
  smartphoneModels,
  currencySymbols,
  currencyInfo,
} = require("./mockData");

function getRandomElementFromArray(array) {
  if (Array.isArray(array) && array.length > 0) {
    const randomIndex = Math.floor(Math.random() * array.length);
    return array[randomIndex];
  } else {
    return null;
  }
}

function getRandomInt(min, max) {
  return min + Math.floor(Math.random() * (max - min + 1));
}

function getRandomSmart() {
  return getRandomElementFromArray(smartphoneModels) + getRandomInt(0, 9);
}

function getRandomCurrencySymbol() {
  return currencySymbols[getRandomInt(0, currencySymbols.length - 1)];
}

function getRandomCurrencyObj() {
  return currencyInfo[getRandomInt(0, currencySymbols.length - 1)];
}

module.exports = {
  getRandomElementFromArray,
  getRandomInt,
  getRandomSmart,
  getRandomCurrencySymbol,
  getRandomCurrencyObj,
};
