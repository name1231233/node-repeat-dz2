/*7. Соляночка общая*/

/*a. Создание каталога товаров:
· Создайте массив объектов, где каждый объект представляет товар (название, цена, количество на складе).

· Напишите функцию, которая принимает этот массив и возвращает новый массив, содержащий только товары, которых на складе меньше 5.

· Добавьте в каждый объект товара свойство discount, которое будет рассчитываться в зависимости от цены (например, скидка 10% для товаров дороже 1000 рублей).*/
/*const morkov = {
    name: "морковь",
    cost: 1500,
    amount: 200
}
const steak = {
    name: "стейк",
    cost: 150,
    amount: 3
}
const moloko = {
    name: "молоко",
    cost: 999,
    amount: 6
}

let massiv2 = [{
        name: "морковь",
        cost: 1500,
        amount: 200
    },
    {
        name: "стейк",
        cost: 1050,
        amount: 3
    },
    {
        name: "молоко",
        cost: 999,
        amount: 6
    }
]

function itemswithdiscount(massiv3) {
    return massiv2.filter(item => item.amount < 5).map(item => {
        let discount = item.cost > 1000 ? (item.cost * 0.1) : 0;
        return {
            ...item,
            discount: discount
        };
    });
};
console.log(itemswithdiscount(massiv2))
↑↑↑↑ не получилось ↑↑↑↑*/